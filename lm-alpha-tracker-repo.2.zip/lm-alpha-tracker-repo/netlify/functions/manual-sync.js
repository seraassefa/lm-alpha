/**
 * manual-sync.js
 * On-demand trigger for the nightly sync — useful for testing or forcing
 * a refresh without waiting for the cron schedule.
 *
 * Call it at: https://your-site.netlify.app/.netlify/functions/manual-sync
 * Protect it with a secret token so only your team can trigger it.
 */

import handler from "./nightly-sync.js";

export default async function manualHandler(req) {
  // Simple token check — set SYNC_SECRET in Netlify env vars
  const secret = process.env.SYNC_SECRET;
  const url = new URL(req.url);
  const token = url.searchParams.get("token");

  if (secret && token !== secret) {
    return new Response("Unauthorized", { status: 401 });
  }

  const result = await handler();
  return new Response(result.body, { status: result.statusCode });
}
