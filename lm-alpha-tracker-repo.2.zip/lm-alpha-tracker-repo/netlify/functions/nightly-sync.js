/**
 * nightly-sync.js
 * Netlify Scheduled Function — runs nightly at 6am UTC (11pm PT)
 * Queries Notion (to-dos) and Airtable (RSVPs), rebuilds the tracker HTML,
 * and writes it to /public/index.html so Netlify serves the latest version.
 *
 * Schedule is set via the NETLIFY_FUNCTION_SCHEDULE env var or the
 * schedule export below. Netlify reads the export automatically.
 */

import { Client as NotionClient } from "@notionhq/client";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ─── Cron schedule: every day at 6am UTC (11pm PT) ───────────────────────────
export const config = {
  schedule: "0 6 * * *",
};

// ─── Notion helpers ───────────────────────────────────────────────────────────
async function fetchNotionItems() {
  const notion = new NotionClient({ auth: process.env.NOTION_API_KEY });
  const dbId = process.env.NOTION_DATABASE_ID;

  const results = [];
  let cursor;

  do {
    const response = await notion.databases.query({
      database_id: dbId,
      start_cursor: cursor,
      page_size: 100,
    });

    for (const page of response.results) {
      const p = page.properties;
      results.push({
        id: page.id,
        item: p["Item"]?.title?.[0]?.plain_text ?? "",
        status: p["Status"]?.status?.name ?? "Not started",
        milestone: p["Milestone"]?.select?.name ?? "",
        category: p["Category"]?.select?.name ?? "",
        owner: p["Owner"]?.rich_text?.[0]?.plain_text ?? "",
        priority: p["Priority"]?.select?.name ?? "",
        due: p["Due Date"]?.date?.start ?? null,
        notes: p["Notes"]?.rich_text?.[0]?.plain_text ?? "",
      });
    }

    cursor = response.has_more ? response.next_cursor : undefined;
  } while (cursor);

  return results;
}

// ─── Airtable helpers ─────────────────────────────────────────────────────────
async function fetchAirtableRSVPs() {
  const baseId = process.env.AIRTABLE_BASE_ID;
  const tableId = process.env.AIRTABLE_TABLE_ID;
  const viewId = process.env.AIRTABLE_VIEW_ID;
  const apiKey = process.env.AIRTABLE_API_KEY;

  const url = `https://api.airtable.com/v0/${baseId}/${tableId}?view=${viewId}&pageSize=100`;
  const headers = { Authorization: `Bearer ${apiKey}` };

  const participants = [];
  let offset;

  do {
    const fetchUrl = offset ? `${url}&offset=${offset}` : url;
    const res = await fetch(fetchUrl, { headers });
    if (!res.ok) throw new Error(`Airtable error: ${res.status} ${res.statusText}`);
    const data = await res.json();

    for (const record of data.records) {
      const f = record.fields;
      // Field IDs from your Airtable base
      const slotRaw = f["Session"] ?? f["Slot"] ?? null;
      const rsvpRaw = slotRaw ?? "No slot";

      let rsvp = "No slot";
      let slot = null;
      if (!slotRaw) {
        rsvp = "No slot";
      } else if (slotRaw === "HOLD") {
        rsvp = "HOLD";
      } else if (slotRaw === "Pending RSVP" || slotRaw === "Pending") {
        rsvp = "Pending RSVP";
      } else {
        rsvp = "Confirmed";
        slot = slotRaw;
      }

      participants.push({
        name: f["Name"] ?? f["Full Name"] ?? "",
        cohort: f["Cohort"] ?? "",
        slot,
        rsvp,
        title: f["Title"] ?? "",
        ea: f["EA"] ?? f["Executive Assistant"] ?? "",
        location: f["Location"] ?? "",
        note: f["Notes"] ?? f["Note"] ?? "",
      });
    }

    offset = data.offset;
  } while (offset);

  return participants;
}

// ─── HTML generator ───────────────────────────────────────────────────────────
function generateHTML(notionItems, participants, syncTime) {
  // Separate done vs open items
  const openItems = notionItems.filter(i => i.status !== "Done");

  // Serialize data as JSON for injection into the HTML
  const notionJSON = JSON.stringify(openItems);
  const airtableJSON = JSON.stringify(participants);
  const syncStr = new Date(syncTime).toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric",
  });

  // Read the base HTML template
  const templatePath = path.join(__dirname, "../../template.html");
  let html = fs.readFileSync(templatePath, "utf8");

  // Inject live data + sync timestamp
  html = html
    .replace("__SYNC_DATE__", syncStr)
    .replace("__NOTION_DATA__", notionJSON)
    .replace("__AIRTABLE_DATA__", airtableJSON);

  return html;
}

// ─── Handler ──────────────────────────────────────────────────────────────────
export default async function handler() {
  console.log("[nightly-sync] Starting sync at", new Date().toISOString());

  try {
    const [notionItems, participants] = await Promise.all([
      fetchNotionItems(),
      fetchAirtableRSVPs(),
    ]);

    console.log(`[nightly-sync] Fetched ${notionItems.length} Notion items, ${participants.length} RSVP records`);

    const html = generateHTML(notionItems, participants, Date.now());

    // Write to the publish directory
    const outPath = path.join(__dirname, "../../public/index.html");
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, html, "utf8");

    console.log("[nightly-sync] Written to", outPath);
    return { statusCode: 200, body: "Sync complete" };
  } catch (err) {
    console.error("[nightly-sync] Error:", err);
    return { statusCode: 500, body: String(err) };
  }
}
